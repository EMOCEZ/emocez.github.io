# -*- coding: utf-8 -*-
# 上面这个注释是ai让我写的，我也不知道为啥，反正我这个垃圾库能被人下载已经很不错了
# 我也不知道，反正这也算python基础吧，所以我就学了，嗯对，很神奇，我不知道
# 我为啥放着好好的图形化编程不管就在那写python啊
# 我要炸了。
def thetextis(s, t):
    yes_set = ["y", "yes", "true", "是", "1",'yes sir','yes men','是的','是的！']
    no_set = ["n", "no", "false", "否", "0",'no sir','no men','不','不！']
    
    if s in ["float?", "number?"]:
        try:
            float(t)
            return True
        except ValueError:
            return False
    elif s == "bool?":
        return t.lower() in ["true", "false"]
    elif s == "y/n?":
        if t.lower() in yes_set: return True
        if t.lower() in no_set: return False
        return None
    else:
        return(None)
def e():
    print("you imported the e!")
    print("(celebrate)")
def itwork(x, e, label="Result"):
    if x == e:
        print(f"{label}: yes! it works!")
    else:
        print(f"{label}: nop (Expected {e}, but got {x})")