# -*- coding: utf-8 -*-
import e
#没想到吧，这里还有说明书
e.e()
#这个没用，下一个
e.itwork(1,1,label="自己想")
#输入2个值，1个可选参数
#第一个值建议为变量
#可以用来查看变量是否符合预期（依然没用）
e.thetextis("bool?","True")
#总共有bool，number，y/n，c 4种检查
#bool和number可以检测字符串是否为对应类型
#y/n可以检查字符串是否为仍和种类的"yes"或"no"
#c可以检查字符串是否为运算符
#记住，任何时候都不要写import e_howtouse
 
 
 
 
 
 
 
 
 
 
 
#预防你导入
print("你为什么要导入说明书")