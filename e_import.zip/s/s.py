#s扩展
#我不知道但是这些都没有用。。。
from time import sleep
from e import thetextis
p=print
i=input
w=sleep
l=len
r=range
def s():
    p("你在干什么？")
def h():
    p("helloworld")
def c(n1,s,n2):
    if thetextis("number?",n1) == True:
       if thetextis("c?",s) == True:
           if thetextis("number?",n2) == True:
               n1 = float(n1)
               n2 = float(n2)
               s = str(s)
               if s == "+":
                   return(n1+n2)
               elif s == "-":
                   return(n1-n2)
               elif s == "*" or s == "×":
                   return(n1*n2)
               elif s == "/" or s == "÷":
                   return(n1/n2)
           else:
               p("输入2不是数字")
       else:
           p("运算符不存在，请输入英文运算符")
    else:
        p("输入1不是数字")