import e
#记得先导入e！
import s
#这玩意同样也有说明书
#总共有这些函数：p,i,w,r,l,h,c,s
s.s()
#比e.e还没用
#p=print,i=input,w=time.sleep,r=range,l=len
s.c(1,"+",1)
#c是我因为觉得这个库太没用了，所以搞出来的，嗯，对。
#大概就是一个计算器，运算符得是英文的，对。
s.h()
#自动输出helloworld，比s.s还没用
#别import s_howtouse