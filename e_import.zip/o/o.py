#无用工具
import time
import sys
def out():
    sys.exit()
def o():
    time.sleep(10086)
def die():
    while True:
        print("isneknsianjsndkansksnaisnzosnksxnkssn")
def nohaveanyting():
    pass